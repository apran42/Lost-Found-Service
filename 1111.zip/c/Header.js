import { Link } from "react-router-dom";
import "./Header.css";
import logo from "../images/logo.png";
import searchIcon from "../images/search-icon.png";

function Header() {
  return (
    <header className="header"> 
      <div className="header-left">
        <Link to="/">
          <img src={logo} alt="로고" className="logo" />
        </Link>
        <div className="search-box"> 
          <input type="text" placeholder="모든 분실물을 빠르게 찾아보세요!" className="search" />
          <button className="search-btn">
            <img src={searchIcon} alt="검색"/>
          </button>
        </div>
       
      </div>
      <div className="header-right">
        <Link to="/login" className="auth-btn">로그인</Link>
      </div>
    </header>
  );
}

export default Header;