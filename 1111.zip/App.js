import { Routes, Route } from "react-router-dom";
import Layout from "./c/Layout";
import MainPage from "./pages/MainPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import LostPage from "./pages/LostPage";
import FoundPage from "./pages/FoundPage";
import BoardPage from "./pages/BoardPage";
function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/lost" element={<LostPage />} />
        <Route path="/found" element={<FoundPage />} />
        <Route path="/board" element={<BoardPage />} />
      </Routes>
    </Layout>
  );
}

export default App;
