import { Link } from "react-router-dom";
import { useState } from "react";
import "./Header.css";
import logo from "../images/logo.png";
import searchIcon from "../images/search-icon.png";
import searchBtn from "../images/search-btn.png";

function Header({ isLogin = false }) {
  const [open, setOpen] = useState(false);

  return (
    <header className="header">

      {/* 왼쪽 로고 */}
      <div className="header-left">
        <Link to="/">
          <img src={logo} alt="로고" className="logo" />
        </Link>
      </div>

      {/* 가운데 검색창 */}
      <div className="header-center">
        <div className="search-box">
          <img src={searchIcon} className="search-icon" alt="검색" />
          <input
            type="text"
            placeholder="모든 분실물을 빠르게 찾아보세요!"
          />
          <button className="search-btn">
            <img src={searchBtn} alt="검색 버튼" />
          </button>
        </div>
      </div>

      {/* 오른쪽 로그인*/}
      <div className="header-right">
        {!isLogin ? (
          <Link to="/login" className="auth-btn">
            로그인
          </Link>
        ) : (/* 오른쪽 로그인/드롭다운 */
          <div className="menu-wrapper">
            <button className="mypage-btn" onClick={() => setOpen(!open)}>
              마이페이지
            </button>

            {open && (
              <div className="dropdown">
                <Link to="/mypage">마이페이지</Link>
                <Link to="/chat">모든 채팅</Link>
                <Link to="/logout">로그아웃</Link>
              </div>
            )}
          </div>
        )}
      </div>

    </header>
  );
}

export default Header;
