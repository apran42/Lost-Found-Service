// src/pages/DeleteAccount.js
import React, { useState } from "react";
import "./AccountPages.css";
import { useNavigate } from "react-router-dom";

function DeleteAccount() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const submit = (e) => {
    e.preventDefault();
    setError("");

    if (!password) {
      setError("비밀번호를 입력해주세요.");
      return;
    }

    // TODO: 실제 회원탈퇴 API 연동
    // const result = await deleteAccountApi(password);
    // if (!result.ok) return setError("비밀번호가 일치하지 않습니다.");

    navigate("/delete-complete");
  };

  return (
    <div className="account-page-wrapper">
      <div className="account-form-container">
        <h2 className="account-title">회원탈퇴</h2>

        <p className="withdraw-desc">
          회원탈퇴를 하시면 계정은 삭제되며, 복구되지 않습니다.
        </p>

        <form onSubmit={submit}>
          <div className="account-field">
            <label>비밀번호</label>
            <input
              type="password"
              placeholder="비밀번호를 입력해주세요."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {error && <p className="account-error">{error}</p>}
          </div>

          <button type="submit" className="account-submit-btn danger">
            회원 탈퇴
          </button>
        </form>
      </div>
    </div>
  );
}

export default DeleteAccount;
