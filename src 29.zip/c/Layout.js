import { useLocation } from "react-router-dom";
import Header from "./Header";
import MainHeader from "./MainHeader";
import Footer from "./Footer";
import { useEffect, useState } from "react";

function Layout({ children }) {
  const location = useLocation();
  const isMainPage = location.pathname === "/";
  const [isLogin, setIsLogin] = useState(false);

  useEffect(() => {
    // 로컬스토리지에서 토큰 확인
    const token = localStorage.getItem('token');
    setIsLogin(!!token);
  }, []);

  return (
    <>
      {isMainPage ? <MainHeader isLogin={isLogin} /> : <Header isLogin={isLogin} />}
      <main>{children}</main>
      <Footer />
    </>
  );
}

export default Layout;
