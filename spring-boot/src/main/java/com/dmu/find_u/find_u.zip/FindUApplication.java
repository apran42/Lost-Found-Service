package com.dmu.find_u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindUApplication {

    public static void main(String[] args) {
        SpringApplication.run(FindUApplication.class, args);
    }

}
