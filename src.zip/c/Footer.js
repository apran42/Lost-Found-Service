import "./Footer.css";
import kakaoIcon from "../images/kakao.png";
import instaIcon from "../images/instagram.png";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-left">
          <p>서비스 정보 : 동양미래대학교 분실물 찾기 서비스</p>
          <p> 
            링크 :{" "}
            <a 
              href="https://www.dongyang.ac.kr"
              target="_blank"
              rel="noopener noreferrer"
            >
              학교홈페이지
            </a>
          </p>
          <p>문의 : hjw57999@gmail.com</p>
          <hr></hr>
          <p>TEL. 02-2610-1700 | FAX. 02-2688-5494</p>
          <p>08221 서울시 구로구 경인로 445 ([구]고척동 62-160) 동양미래대학교</p>
        </div>
        <div className="footer-right">
          <a href="https://open.kakao.com" target="_blank" rel="noopener noreferrer">
            <img src={kakaoIcon} alt="카카오톡" />
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
            <img src={instaIcon} alt="인스타그램" />
          </a>
        </div>
      </div>
       <div className="footer-copy">
        COPYRIGHT(c) DONGYANG MIRAE UNIVERSITY. ALL RIGHTS RESERVED.
      </div>
    </footer>
  );
}


export default Footer;