import React, { useState } from "react";
import "./BoardPage.css";
import searchIcon from "../images/search-icon.png";
function BoardPage() {
  // 예시 게시글 데이터
  const posts = [
    { id: 301, date: "2025.09.01", type: "습득", title: "경정석 입실공간 반지갑 습득하신분 찾습니다.", place: "3호관", category: "지갑", writer: "황지원" },
    { id: 300, date: "2025.08.29", type: "분실", title: "경정석 입실공간 반지갑 분실했습니다.", place: "1호관", category: "에어팟", writer: "황지원" },
    { id: 299, date: "2025.09.01", type: "분실", title: "경정석 입실공간 반지갑 습득하신분 찾습니다.", place: "3호관", category: "지갑", writer: "황지원" },
    { id: 298, date: "2025.08.29", type: "습득", title: "경정석 입실공간 반지갑 분실했습니다.", place: "1호관", category: "에어팟", writer: "황지원" },
    { id: 297, date: "2025.09.01", type: "습득", title: "경정석 입실공간 반지갑 습득하신분 찾습니다.", place: "3호관", category: "지갑", writer: "황지원" },
    { id: 296, date: "2025.08.29", type: "습득", title: "경정석 입실공간 반지갑 분실했습니다.", place: "1호관", category: "에어팟", writer: "황지원" },
    { id: 295, date: "2025.09.01", type: "분실", title: "경정석 입실공간 반지갑 습득하신분 찾습니다.", place: "3호관", category: "지갑", writer: "황지원" },
    { id: 294, date: "2025.08.29", type: "습득", title: "경정석 입실공간 반지갑 분실했습니다.", place: "1호관", category: "에어팟", writer: "황지원" },
  ];

  const [searchTerm, setSearchTerm] = useState("");

  const filteredPosts = posts.filter((post) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="board-container">
      <div className="board-header">
        <h2>전체 보기</h2>
        <div className="filters">
          <input type="date" className="filter-input" />
          <select className="filter-select">
            <option>전체 분류</option>
            <option>분실</option>
            <option>습득</option>
          </select>
          <select className="filter-select">
            <option>카테고리</option>
            <option>지갑</option>
            <option>에어팟</option>
            <option>전자기기</option>
          </select>
          <select className="filter-select">
            <option>장소</option>
            <option>1호관</option>
            <option>3호관</option>
            <option>5호관</option>
          </select>
          <div className="search-box">
            <input
              type="text"
              placeholder="제목을 검색하세요"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button><img src={searchIcon} alt="검색"/></button>
          </div>
          <button className="write-btn">글쓰기</button>
        </div>
      </div>

      <table className="board-table">
        <thead>
          <tr>
            <th>NO</th>
            <th>작성일</th>
            <th>분류</th>
            <th>제목</th>
            <th>장소</th>
            <th>카테고리</th>
            <th>작성자명</th>
          </tr>
        </thead>
        <tbody>
          {filteredPosts.map((post) => (
            <tr key={post.id}>
              <td>{post.id}</td>
              <td>{post.date}</td>
              <td>{post.type}</td>
              <td className="title">{post.title}</td>
              <td>{post.place}</td>
              <td>{post.category}</td>
              <td>{post.writer}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
        <button>{"<<"}</button>
        <button>{"<"}</button>
        <button className="active">1</button>
        <button>2</button>
        <button>3</button>
        <button>{">"}</button>
        <button>{">>"}</button>
      </div>
    </div>
  );
}

export default BoardPage;
