import { Routes, Route } from "react-router-dom";
import Layout from "./c/Layout";
import MainPage from "./pages/MainPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import LostPage from "./pages/LostPage";
import FoundPage from "./pages/FoundPage";
import BoardPage from "./pages/BoardPage";
import MyPage from "./pages/MyPage";
import ProfileEdit from "./pages/ProfileEdit";
import PasswordChange from "./pages/PasswordChange";
import DeleteAccount from "./pages/DeleteAccount";
import DeleteComplete from "./pages/DeleteComplete";
import WritePostPage from "./pages/WritePostPage";
import ChatPage from "./pages/ChatPage";
import PostDetail from "./pages/PostDetail";
/* useEffect removed — synchronous removal used for development */

function App() {

  // 개발/디버그: 렌더링 전에 로컬스토리지에서 로그인 정보를 동기적으로 제거합니다.
  // 개발용 처리이므로 실제 배포 시 제거하세요.
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  } catch (e) {
    // 일부 환경에서 localStorage 접근이 실패할 수 있음 — 무시
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/lost" element={<LostPage />} />
        <Route path="/found" element={<FoundPage />} />
        <Route path="/board" element={<BoardPage />} />
        <Route path="/mypage" element={<MyPage />} />
        <Route path="/profileedit" element={<ProfileEdit/>}/>
        <Route path="/profile-edit" element={<ProfileEdit />} />
        <Route path="/password-change" element={<PasswordChange />} />
        <Route path="/delete-account" element={<DeleteAccount />} />
        <Route path="/delete-complete" element={<DeleteComplete />} />
        <Route path="/writepage" element={<WritePostPage/>}/>
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/post/:id" element={<PostDetail />} />
      </Routes>
    </Layout>
  );
}

export default App;
